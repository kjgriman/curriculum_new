<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class prueba extends Model
{
    //
    protected $table='category';
    public  $timestamps = false;



}
