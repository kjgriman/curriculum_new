



<h1>hola kerbin</h1>
@for($i=0;$i<count($xxx);$i++)
	{{$xxx[$i]['name_courses']}}
@endfor
