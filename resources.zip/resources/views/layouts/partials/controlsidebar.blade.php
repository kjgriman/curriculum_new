<!-- Control Sidebar -->
<aside class="">
    <!-- Create the tabs -->
 
    <!-- Tab panes -->
    
</aside><!-- /.control-sidebar

<!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
