<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    
    <!-- Default to the left -->
    <strong>.</strong> {{ trans('adminlte_lang::message.createdby') }} <a href="http://kjgriman.wixsite.com/kjgm">Griman Kerbin</a>. 
</footer>